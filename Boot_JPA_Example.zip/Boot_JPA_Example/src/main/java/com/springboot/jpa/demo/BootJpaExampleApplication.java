package com.springboot.jpa.demo;


import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.springboot.jpa.dao.UserRepository;
import com.springboot.jpa.entities.User;

@SpringBootApplication

public class BootJpaExampleApplication {

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(BootJpaExampleApplication.class, args);
	UserRepository userrepo =	context.getBean(UserRepository.class);
	/*
	 * //object creation
	 *  User user=new User();
	 *   user.setName("Praneeth");
	 * user.setCity("palasa"); 
	 * user.setStatus("learner");
	 * 
	 * //to save 
	 * User user1 = userrepo.save(user); 
	 * System.out.println(user1);
	 */
	
	
	
	// to create object of user 
	 User user2= new User();
	 user2.setName("hyma");
	 user2.setCity("chennai");
	 user2.setStatus("low height ");
	
	 User user1= new User();
	 user1.setName("usha");
	 user1.setCity("hyd");
	 user1.setStatus("low height too ");
	 
	 
	 //to SAVE
	User resultUser= userrepo.save(user1);
	 //object will save for user 1  
	System.out.println("saved user "+resultUser);
	
	
	
	
	/*
	 * // to save all the users at a time
	 *  List<User> users =List.of(user1,user2);
	 * Iterable<User> result = userrepo.saveAll(users); 
	 * result.forEach(x->{ //
	 * System.out.println(x); });
	 */
	
	

//	// to update the user ex : id 11
//	// 1st get the data 
//	Optional<User>optional = userrepo.findById(11);
//	User x = optional.get();
//	x.setName("preethi");
//	User result1 = userrepo.save(x);
//	System.out.println(result1);
//	
	
	
	// to get the data 
	//findById(id) -->return optional containing your data.
	//to get all the data 
	/*
	 * Iterable<User>itr = userrepo.findAll();
	 *  Iterator<User> iterator =itr.iterator();
	 *  while (iterator.hasNext()) 
	 *  {
	 *   User user=iterator.next();
	 * System.out.println(user); 
	 * }
	 */
	
	
	/*
	 * //another way to get all the data
	 *  Iterable<User>itr = userrepo.findAll();
	 * itr.forEach(user->{System.out.println(user);});
	 */
	
	
	
	//to delete the user element
	userrepo.deleteById(11);
	//to delete all 
	userrepo.deleteAll();
	
	
	//to get customized methods 
	List<User>users=userrepo.findByName("praneeth");
	users.forEach(e->System.out.println(e));
	
	
	
   // to get customized methods with Keywords 
	List<User>users1=userrepo.findByNameAndCity("praneeth","palasa");
	users1.forEach(e->System.out.println(e));
	
	
	
	//Executing Query with @Query in Spring data Jpa:
    List<User> allUser = userrepo.getAllUser();
    allUser.forEach(e->{System.out.println(e);});
    
    
	//to pass parameter while Executing Query with @Query in Spring data Jpa
    List<User> userByName = userrepo.getUserByName("praneeth");
    userByName.forEach(e->{System.out.println(e);});


  //code for native query
    userrepo.getUsers().forEach(e->{System.out.println(e);});
	
	
    
    
	
	}

	
	
	
	}
	
	
