package com.springboot.jpa.dao;



import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.springboot.jpa.entities.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer>{

	public List<User> findByName(String name);
//public List<User> findByCity(String city);
//in findbyname ---> find specifies introducer
// byname specifies criteria 
//name --> means property 
 

	
//to get customized methods with Keywords 
public List<User> findByNameAndCity(String name,String city);



//Executing Query with @Query in Spring data Jpa:
@Query("select  u FROM User u")
public List<User> getAllUser();



//to pass parameter while Executing Query with @Query in Spring data Jpa
//n-->refers to name 
// with help of @param we do that.
@Query("select  u FROM User u WHERE u.name= :n")
public List<User> getUserByName(@Param("n")String name);


//code for native query
@Query(value = "select * from user",nativeQuery = true)
public List<User> getUsers();


}
