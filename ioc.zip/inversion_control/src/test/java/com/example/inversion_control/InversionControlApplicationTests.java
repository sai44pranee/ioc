package com.example.inversion_control;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InversionControlApplicationTests {

	@Test
	void contextLoads() {
	}

}
