package com.example.inversion_control;

public class OnePlus implements Mobiles {
	
	Color color;//new color();
	//initializing
	OnePlus(){
		System.out.println("OnePlus constructor triggered");
	}
	
	OnePlus(Color colorObj){
		this.color=colorObj;
	}
	@Override
	public void getModelAndColor() {
		// TODO Auto-generated method stub
     System.out.println( "model : 9 Pro Max");
    color.getOnePlusColor();
	}

}
