package com.example.inversion_control;

public class IPhone implements Mobiles {

	Color color;//new color();
	//initializing
	IPhone(){
		System.out.println("IPone constructor triggered");
	}
	
	IPhone(Color colorObj){
		this.color=colorObj;
	}
	@Override
	public void getModelAndColor() {
		// TODO Auto-generated method stub
		System.out.println("Model :13pro Max");
		color.getIPhoneColor();
	}

}
