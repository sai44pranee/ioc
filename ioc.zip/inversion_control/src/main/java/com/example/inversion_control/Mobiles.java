package com.example.inversion_control;

public interface Mobiles {
public void getModelAndColor();
}
