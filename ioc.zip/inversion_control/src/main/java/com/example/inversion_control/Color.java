package com.example.inversion_control;

public class Color {
	public void getOnePlusColor() {
		System.out.println("Black");
	}
	public void getIPhoneColor() {
		System.out.println("White");
	}
}
